#' Plot Chromosome Ideograms with Enhanced Functional Arm Support
#'
#' Creates comprehensive ideogram plots showing chromosome arms with functional regions.
#' Supports both telomere-direction (telomere to breakpoint) and centromere-direction
#' (centromere to breakpoint) arm definitions with proper p/q arm directional handling.
#' Individual plots for each chromosome and combined panel plots are generated.
#'
#' @param arm_definitions arm_definitions with telcent column ("telomere" or "centromere")
#' @param output_dir Character, directory to save plots (default: current directory)
#' @param cytoband_data Data frame, cytoband data for chromosome boundaries (default: BISCUT coordinates)
#' @param plot_width Numeric, width of individual plots in inches (default: 3)
#' @param plot_height Numeric, height of individual plots in inches (default: 3)
#' @param save_plots Logical, whether to save plots to files (default: TRUE)
#' @return List containing individual plots, combined plot, colors, and output directory
#' @import ggplot2
#' @import dplyr
#' @importFrom RColorBrewer brewer.pal
#' @export
plot_ideograms <- function(arm_definitions,
                           output_dir = ".",
                           dir_name = "arms_ideogram", 
                           plot_width = 3,
                           plot_height = 3,
                           save_plots = TRUE) {
  
  
  # Validate input data
  if (is.null(arm_definitions) || nrow(arm_definitions) == 0) {
    stop("No arm definitions found in arm_definitions")
  }
  
  # Create output directory
  ideogram_dir <- NULL
  if (save_plots) {
    ideogram_dir <- file.path(output_dir, dir_name)
    if (!dir.exists(ideogram_dir)) {
      dir.create(ideogram_dir, recursive = TRUE)
      cat("Created ideogram directory:", ideogram_dir, "\n")
    }
  }
  
  # Setup chromosome colors
  chromosomes_to_plot <- sort(unique(arm_definitions$chr))
  set.seed(999)
  chr_colors <- sample(BAGEL::bagel_palette, size = 23, replace = FALSE)
  names(chr_colors) <- paste0("chr", 1:23)
  chr_colors <- chr_colors[as.character(chromosomes_to_plot)]
  
  # Create individual chromosome plots
  individual_plots <- list()
  
  for (chr_num in chromosomes_to_plot) {
    cat("Creating ideogram for chromosome", chr_num, "\n")

    # Extract arm data
    plot_data <- arm_definitions %>% 
      dplyr::filter(chr == chr_num)
    
    # Make base-plot using direct coordinates ---------------------------------
    background <- plot_data %>%
      dplyr::select(p_start:q_end) %>%
      distinct()

    # Extract genomic coordinates
    p_start <- background$p_start
    p_end <- background$p_end
    p_length <- p_end - p_start
    q_start <- background$q_start
    q_end <- background$q_end
    q_length <- q_end - q_start

    # get colour
    chr_color <- chr_colors[as.character(chr_num)]

    # Create base plot using direct genomic coordinates
    # P arm: 0 (centromere) to p_length (telomere) - plotted ABOVE y=0
    # Q arm: -q_length (telomere) to 0 (centromere) - plotted BELOW y=0
    base_plot <- ggplot() +
      # P arm background (50% transparency) - ABOVE y=0
      geom_rect(aes(xmin = -0.3, xmax = 0.3,
                    ymin = 0, ymax = p_length),
                fill = chr_color, alpha = 0.5, color = "black", linewidth = 0.5) +

      # Q arm background (50% transparency) - BELOW y=0
      geom_rect(aes(xmin = -0.3, xmax = 0.3,
                    ymin = -q_length, ymax = 0),
                fill = chr_color, alpha = 0.5, color = "black", linewidth = 0.5) +

      # P arm boundary labels
      geom_text(aes(x = 0.4, y = p_length,
                    label = format(p_start, big.mark = ",")),
                size = 3, hjust = 0) +  # Telomere (top)
      geom_text(aes(x = 0.4, y = 0,
                    label = format(p_end, big.mark = ",")),
                size = 3, hjust = 0) +  # Centromere

      # Q arm boundary labels
      geom_text(aes(x = -0.4, y = 0,
                    label = format(q_start, big.mark = ",")),
                size = 3, hjust = 1) +  # Centromere
      geom_text(aes(x = -0.4, y = -q_length,
                    label = format(q_end, big.mark = ",")),
                size = 3, hjust = 1) +  # Telomere (bottom)

      # Arm labels
      geom_text(aes(x = 0, y = p_length / 2, label = "p"),
                size = 4, fontface = "bold") +
      geom_text(aes(x = 0, y = -q_length / 2, label = "q"),
                size = 4, fontface = "bold")
    
    # Add functional regions using direct coordinates -------------------------
    if (nrow(plot_data) > 0) {
      for (i in 1:nrow(plot_data)) {
        arm_def <- plot_data[i, ]
        arm_type <- arm_def$arm

        # Get functional region coordinates
        func_start <- arm_def$functional_start
        func_end <- arm_def$functional_end

        # Calculate plot coordinates using direct genomic positions
        if (arm_type == "p") {
          # P arm: centromere at 0, telomere at p_length
          # Convert genomic coords to plot coords
          func_y_start <- p_end - func_start  # Distance from centromere
          func_y_end <- p_end - func_end

          # Ensure correct order (ymin < ymax)
          func_ymin <- min(func_y_start, func_y_end)
          func_ymax <- max(func_y_start, func_y_end)

        } else {
          # Q arm: centromere at 0, telomere at -q_length
          # Convert genomic coords to plot coords
          func_y_start <- -(func_start - q_start)  # Negative for below y=0
          func_y_end <- -(func_end - q_start)

          # Ensure correct order (ymin < ymax)
          func_ymin <- min(func_y_start, func_y_end)
          func_ymax <- max(func_y_start, func_y_end)
        }

        # Create event-specific plot
        event_plot <- base_plot +
          geom_rect(aes(xmin = -0.3, xmax = 0.3,
                        ymin = func_ymin, ymax = func_ymax),
                    fill = chr_color, alpha = 1.0, color = "black", linewidth = 0.5)

        # Add breakpoint coordinate label
        label_coord <- if (arm_def$telcent == "tel") func_end else func_start
        label_x <- if (arm_type == "p") 0.4 else -0.4
        label_hjust <- if (arm_type == "p") 0 else 1
        label_y <- (func_ymin + func_ymax) / 2

        event_plot <- event_plot +
          geom_text(aes(x = label_x, y = label_y,
                        label = format(label_coord, big.mark = ",")),
                    hjust = label_hjust, size = 3, color = "red", fontface = "bold") +

          # Direction and telcent annotation
          geom_text(aes(x = 1.8, y = func_ymin,
                        label = paste0(arm_def$direction, "\n",
                                       arm_def$telcent, "\n",
                                       arm_def$negpos)),
                    hjust = 1, vjust = 0, size = 3,
                    color = if(arm_def$direction == "amp") "red" else "blue",
                    fontface = "bold")

        # Apply theme and styling
        event_plot <- event_plot +
          theme_minimal() +
          labs(title = paste("Chromosome", chr_num, "-", arm_def$peak_id)) +
          theme(axis.text = element_blank(),
                axis.title = element_blank(),
                plot.title = element_text(size = 10, face = "bold", hjust = 0.5),
                panel.grid = element_blank()) +
          coord_cartesian(xlim = c(-2, 2))  # Let y-axis auto-scale

        # Create unique identifier
        event_id <- paste(arm_def$chr_arm, arm_def$direction, arm_def$telcent, arm_def$negpos, sep = "_")

        # Store plot in individual_plots
        individual_plots[[event_id]] <- event_plot
      }
    }
    

    
    # Save individual plot
    if (save_plots) {
      filename <- file.path(ideogram_dir, paste0("chromosome_", chr_num, "_ideogram.png"))
      ggsave(filename = filename, plot = plot,
             width = plot_width, height = plot_height,
             units = "in", dpi = 300)
    }
  }
  
  # Create combined panel plot
  combined_plot <- NULL
  if (length(individual_plots) > 0) {
    n_plots <- length(individual_plots)
    
    if (n_plots <= 4) {
      combined_plot <- wrap_plots(individual_plots, nrow = 1)
      panel_width <- n_plots * plot_width
      panel_height <- plot_height
    } else {
      ncol <- 4
      nrow <- ceiling(n_plots / ncol)
      combined_plot <- wrap_plots(individual_plots, ncol = ncol)
      panel_width <- ncol * plot_width
      panel_height <- nrow * plot_height
    }
    
    # Save combined plot
    if (save_plots) {
      combined_filename <- file.path(ideogram_dir, "all_chromosomes_ideogram_panel.png")
      ggsave(filename = combined_filename, plot = combined_plot,
             width = panel_width, height = panel_height,
             units = "in", dpi = 300)
      cat("Saved combined panel plot:\n", combined_filename, "\n")
    }
  }
  
  # Return results
  return(list(
    individual_plots = individual_plots,
    combined_plot = combined_plot,
    chromosome_colors = chr_colors,
    output_directory = if (save_plots) ideogram_dir else NULL,
    plot_metadata = list(
      total_chromosomes = length(chromosomes_to_plot),
      functional_regions = nrow(arm_definitions),
      telcent_support = "telcent" %in% names(arm_definitions)
    )
  ))
}



