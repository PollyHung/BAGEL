#' Process BISCUT Results with Enhanced Functional Aneuploidy Definitions
#'
#' Processes BISCUT analysis results to create biologically meaningful functional
#' aneuploidy definitions based on breakpoint analysis and evolutionary selection pressure.
#' This enhanced version supports telomere/centromere boundary logic, selection type
#' classification, and enriched output format compatible with enhanced arm × sample matrices.
#'
#' @param biscut_results_file Character, path to BISCUT all_BISCUT_results.txt file
#' @param mode Character, processing mode: "functional" (enhanced) or "simple" (legacy)
#' @param min_statistical_support Numeric, minimum n_right + n_left for peak inclusion (default: 10)
#' @param min_combined_sig Numeric, minimum combined significance score (default: 1.0)
#' @param include_gene_annotation Logical, whether to count genes in functional regions (default: FALSE)
#' @return Data frame with enhanced functional aneuploidy definitions
#' @import dplyr
#' @importFrom readr read_delim
#' @export
process_biscut_results <- function(biscut_results_file,
                                   mode = "functional",
                                   min_statistical_support = 10,
                                   min_combined_sig = 1.0,
                                   include_gene_annotation = FALSE) {
  
  # Input validation
  if (!file.exists(biscut_results_file)) {
    stop("BISCUT results file not found: ", biscut_results_file)
  }
  
  if (!mode %in% c("functional", "simple")) {
    stop("Mode must be either 'functional' or 'simple'")
  }
  
  # Load BISCUT results with enhanced column detection
  tryCatch({
    biscut_data <- readr::read_delim(biscut_results_file, delim = "\t", show_col_types = FALSE)
    cat("Loaded BISCUT results:", nrow(biscut_data), "entries\n")
    
    # Validate required columns for enhanced processing
    if (mode == "functional") {
      required_cols <- c("peak_id", "Chr", "arm", "direction", "telcent", "negpos",
                         "type_of_selection", "Peak.Start", "Peak.End",
                         "combined_sig", "n_right", "n_left")
      missing_cols <- setdiff(required_cols, colnames(biscut_data))
      if (length(missing_cols) > 0) {
        warning("Missing enhanced columns, falling back to simple mode: ",
                paste(missing_cols, collapse = ", "))
        mode <- "simple"
      }
    }
    
  }, error = function(e) {
    stop("Error reading BISCUT results file: ", e$message)
  })
  
  # ============================================================================
  # ENHANCED FUNCTIONAL PROCESSING MODE
  # ============================================================================
  if (mode == "functional") {
    # -------------------------------------------------------------------------
    # STEP 1: Extract and Structure Peak-Level Data
    # -------------------------------------------------------------------------
    peak_data <- biscut_data %>%
      dplyr::mutate(negpos = case_when(negpos == "p" ~ "pos", 
                                       negpos == "n" ~ "neg", 
                                       TRUE ~ "what"),
                    Peak_ID = paste0(arm, ":", Peak.Start, "-", Peak.End, ":", direction, ":", telcent, ":", negpos)) %>% 
      dplyr::select(Peak_ID, Chr, arm, Peak.Start, Peak.End, direction, telcent, 
                    negpos, type_of_selection, ks_stat, ks_p, combined_sig) %>% 
      distinct()
    
    # -------------------------------------------------------------------------
    # STEP 2: Define Functional Boundaries Using Telomere/Centromere Logic
    # -------------------------------------------------------------------------
    # Load chromosome coordinate information with robust error handling
    coord_data <- BISCUT::get_chromosome_coordinates()
    
    # Create functional definitions with boundary logic
    functional_defs <- peak_data %>%
      dplyr::mutate(Chr = as.numeric(Chr)) %>%
      dplyr::left_join(coord_data, by = c("Chr" = "chromosome_info")) %>%
      dplyr::mutate(
        # Extract arm type
        arm_type = ifelse(str_remove(arm, "[0-9]*") == "", "q", str_remove(arm, "[0-9]*")),
        chr_num = Chr,
        
        # Define functional coordinates based on boundary logic
        functional_start = case_when(
          arm_type == "p" & telcent == "tel" ~ p_start, # P-arm + telomere-bounded → telomere to peak_end
          arm_type == "p" & telcent == "cent" ~ Peak.Start, # P-arm + centromere-bounded → peak_start to p-arm end
          arm_type == "q" & telcent == "tel" ~ Peak.Start, # Q-arm + telomere-bounded → peak start to q-arm end
          arm_type == "q" & telcent == "cent" ~ q_start1, # Q-arm + centromere-bounded → telomere to peak_start
          TRUE ~ NA_integer_
        ),
        
        functional_end = case_when(
          arm_type == "p" & telcent == "tel" ~ Peak.End, # P-arm + telomere-bounded → telomere (1) to peak_end
          arm_type == "p" & telcent == "cent" ~ p_end, # P-arm + centromere-bounded → peak_start to centromere
          arm_type == "q" & telcent == "tel" ~ q_end1, # Q-arm + telomere-bounded → centromere to peak_start
          arm_type == "q" & telcent == "cent" ~ Peak.End, # Q-arm + centromere-bounded → peak_end to chromosome_end
          TRUE ~ NA_integer_
        ),
        
        # Create functional region identifiers
        functional_arm_id = paste0(arm, ":", functional_start, "-", functional_end, ":", direction, ":", telcent, ":", negpos),
        
        # Calculate region metrics
        functional_length_mb = round((functional_end - functional_start) / 1e6, 2),
        functional_coordinates = paste0("chr", chr_num, ":", functional_start, "-", functional_end)
      ) %>%
      filter(
        !is.na(functional_start),
        !is.na(functional_end),
        functional_start < functional_end,
        functional_length_mb > 0.1  # Minimum 100kb regions
      )
    
    # Add missing columns to match expected enhanced format
    enhanced_definitions <- functional_defs %>%
      mutate(
        # Create boundary type classification
        boundary_type = case_when(
          telcent == "tel" ~ "telomere_bounded",
          telcent == "cent" ~ "centromere_bounded",
          TRUE ~ "unknown"
        ),

        # Create selection type classification
        selection_type = case_when(
          type_of_selection == "TS-like" ~ "tumor_suppressor_like",
          type_of_selection == "onco-like" ~ "oncogene_like",
          type_of_selection == "essential-like" ~ "essential_gene_like",
          type_of_selection == "toxic-like" ~ "toxic_amplification_like",
          TRUE ~ "unknown"
        ),

        # Add other enhanced fields
        chromosome_arm = arm,
        peak_significance = combined_sig,
        statistical_support = ifelse("n_right" %in% colnames(.) & "n_left" %in% colnames(.),
                                   n_right + n_left, NA_integer_),
        biscut_peak_id = Peak_ID,
        peak_center = round((Peak.Start + Peak.End) / 2),
        support_ratio = ifelse(!is.na(statistical_support) & statistical_support > 0,
                              round(combined_sig / statistical_support, 3), NA_real_),
        genes_in_region = NA_integer_  # Placeholder for gene annotation
      ) %>%
      select(
        functional_arm_id,
        chromosome_arm,
        chr_num,
        arm_type,
        boundary_type,
        selection_type,
        functional_coordinates,
        functional_start,
        functional_end,
        functional_length_mb,
        genes_in_region,
        peak_significance,
        statistical_support,
        biscut_peak_id,
        direction,
        peak_center,
        support_ratio
      ) %>%
      arrange(chr_num, arm_type, functional_start)

    cat("Generated", nrow(enhanced_definitions), "functional aneuploidy definitions\n")

    # Summary statistics using correct column names
    summary_stats <- enhanced_definitions %>%
      group_by(direction, boundary_type) %>%
      summarise(
        n_regions = n(),
        avg_length_mb = round(mean(functional_length_mb, na.rm = TRUE), 2),
        avg_significance = round(mean(peak_significance, na.rm = TRUE), 2),
        .groups = "drop"
      )

    cat("\nFunctional regions summary:\n")
    print(summary_stats)

    return(enhanced_definitions)
    
  } else {
    # ========================================================================
    # SIMPLE ARM-LEVEL PROCESSING MODE (Legacy)
    # ========================================================================
    cat("=== Simple Arm-Level Processing Mode ===\n")
    
    # Create arm-level breakpoint summary
    arm_breakpoints <- biscut_data %>%
      group_by(arm, direction) %>%
      summarise(
        chr = unique(Chr)[1],
        n_peaks = n(),
        peak_start = min(Peak.Start),
        peak_end = max(Peak.End),
        direction = unique(direction),
        telcent = if("telcent" %in% colnames(.)) unique(telcent)[1] else NA_character_,
        negpos = if("negpos" %in% colnames(.)) unique(negpos)[1] else NA_character_,
        type_of_selection = if("type_of_selection" %in% colnames(.)) unique(type_of_selection)[1] else NA_character_,
        .groups = "drop"
      )
    
    cat("Processed", nrow(arm_breakpoints), "arm-level breakpoints\n")
    
    # Get chromosome coordinates
    coord_data <- tryCatch({
      if (requireNamespace("BISCUT", quietly = TRUE)) {
        BISCUT::get_chromosome_coordinates()
      } else {
        data.frame(
          chromosome = 1:22,
          chromosome_length = c(249250621, 243199373, 198022430, 191154276, 180915260,
                                171115067, 159138663, 146364022, 141213431, 135534747,
                                135006516, 133851895, 115169878, 107349540, 102531392,
                                90354753, 81195210, 78077248, 59128983, 63025520,
                                48129895, 51304566)
        )
      }
    }, error = function(e) {
      warning("Could not load BISCUT coordinates: ", e$message)
      data.frame(
        chromosome = 1:22,
        chromosome_length = c(249250621, 243199373, 198022430, 191154276, 180915260,
                              171115067, 159138663, 146364022, 141213431, 135534747,
                              135006516, 133851895, 115169878, 107349540, 102531392,
                              90354753, 81195210, 78077248, 59128983, 63025520,
                              48129895, 51304566)
      )
    })
    
    # Create simple arm definitions
    arm_definitions <- arm_breakpoints %>%
      mutate(
        chr_num = as.numeric(chr),
        arm_type = ifelse(grepl("p$", arm), "p", "q")
      ) %>%
      filter(!is.na(chr_num), !is.na(peak_start), !is.na(peak_end)) %>%
      left_join(
        coord_data %>%
          select(chromosome, chromosome_length) %>%
          rename(chr_num = chromosome),
        by = "chr_num"
      ) %>%
      mutate(
        arm_start = case_when(
          arm_type == "p" ~ 1,                  # p arm always starts at position 1
          arm_type == "q" ~ peak_start          # q arm starts at functional breakpoint
        ),
        arm_end = case_when(
          arm_type == "p" ~ peak_end,           # p arm ends at functional breakpoint
          arm_type == "q" ~ chromosome_length   # q arm ends at chromosome end
        )
      ) %>%
      filter(!is.na(arm_start) & !is.na(arm_end) & arm_start < arm_end) %>%
      select(arm, chr_num, arm_type, arm_start, arm_end, direction) %>%
      arrange(chr_num, arm_type)
    
    cat("Generated arm definitions for", length(unique(arm_definitions$chr_num)),
        "chromosomes covering", nrow(arm_definitions), "functional regions\n")
    
    # Summary of detected alterations
    summary_stats <- arm_definitions %>%
      group_by(direction) %>%
      summarise(n_arms = n(), .groups = "drop")
    
    cat("Alteration summary:\n")
    for (i in 1:nrow(summary_stats)) {
      cat("  ", summary_stats$direction[i], ":", summary_stats$n_arms[i], "arms\n")
    }
    
    return(arm_definitions)
  }
}

#' Create Enhanced Functional Aneuploidy Definitions
#'
#' Enhanced wrapper function that creates functional aneuploidy definitions
#' with comprehensive validation and export options for both simple and
#' enhanced processing modes.
#'
#' @param biscut_results_file Character, path to BISCUT all_BISCUT_results.txt file
#' @param mode Character, processing mode: "functional" (enhanced) or "simple" (legacy)
#' @param output_file Character, optional path to save definitions (default: NULL)
#' @param min_statistical_support Numeric, minimum statistical support for peaks (default: 10)
#' @param min_combined_sig Numeric, minimum combined significance score (default: 1.0)
#' @param include_gene_annotation Logical, whether to include gene counts (default: FALSE)
#' @return Data frame with validated functional aneuploidy definitions
#' @import dplyr
#' @export
create_custom_arm_definitions <- function(biscut_results_file,
                                          mode = "functional",
                                          output_file = NULL,
                                          min_statistical_support = 10,
                                          min_combined_sig = 1.0,
                                          include_gene_annotation = FALSE) {
  
  cat("=== Creating Enhanced BISCUT Functional Definitions ===\n")
  cat("Input file:", biscut_results_file, "\n")
  cat("Processing mode:", mode, "\n")
  
  # Process BISCUT results with enhanced functionality
  definitions <- process_biscut_results(
    biscut_results_file = biscut_results_file,
    mode = mode,
    min_statistical_support = min_statistical_support,
    min_combined_sig = min_combined_sig,
    include_gene_annotation = include_gene_annotation
  )
  
  # Validate output format based on mode
  if (mode == "functional") {
    # Enhanced validation for functional mode
    required_cols <- c("functional_arm_id", "chromosome_arm", "chr_num",
                       "boundary_type", "selection_type", "functional_coordinates",
                       "functional_start", "functional_end", "direction")
    
    validation_checks <- list(
      chr_num = all(definitions$chr_num %in% 1:22 & !is.na(definitions$chr_num)),
      boundary_type = all(definitions$boundary_type %in% c("telomere_bounded", "centromere_bounded")),
      positions = all(definitions$functional_start < definitions$functional_end),
      direction = all(definitions$direction %in% c("amp", "del")),
      selection_type = all(!is.na(definitions$selection_type))
    )
    
    cat("✅ Enhanced functional definitions validated successfully\n")
    
  } else {
    # Simple validation for legacy mode
    required_cols <- c("arm", "chr_num", "arm_type", "arm_start", "arm_end", "direction")
    
    validation_checks <- list(
      chr_num = all(definitions$chr_num %in% 1:22 & !is.na(definitions$chr_num)),
      arm_type = all(definitions$arm_type %in% c("p", "q")),
      positions = all(definitions$arm_start < definitions$arm_end),
      direction = all(definitions$direction %in% c("amp", "del"))
    )
    
    cat("✅ Simple arm definitions validated successfully\n")
  }
  
  # Check for missing required columns
  missing_cols <- setdiff(required_cols, colnames(definitions))
  if (length(missing_cols) > 0) {
    stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
  }
  
  # Run validation checks
  failed_checks <- names(validation_checks)[!unlist(validation_checks)]
  if (length(failed_checks) > 0) {
    stop("Validation failed for: ", paste(failed_checks, collapse = ", "))
  }
  
  # Export enhanced formats if functional mode
  if (mode == "functional" && !is.null(output_file)) {
    # Export multiple formats for enhanced mode
    base_name <- tools::file_path_sans_ext(output_file)
    
    # Main functional definitions
    readr::write_tsv(definitions, paste0(base_name, "_functional_definitions.tsv"))
    
    # GISTIC-style matrix format
    gistic_format <- definitions %>%
      mutate(
        region_id = paste0(chromosome_arm, "_", boundary_type, "_", selection_type),
        significance_score = round(peak_significance, 3)
      ) %>%
      select(
        region_id, chromosome_arm, functional_coordinates,
        functional_length_mb, direction, boundary_type,
        selection_type, significance_score, statistical_support
      )
    readr::write_tsv(gistic_format, paste0(base_name, "_gistic_format.tsv"))
    
    # Comprehensive summary
    summary_stats <- definitions %>%
      group_by(chromosome_arm, direction, boundary_type, selection_type) %>%
      summarise(
        n_regions = n(),
        total_length_mb = sum(functional_length_mb),
        avg_significance = round(mean(peak_significance), 3),
        max_significance = round(max(peak_significance), 3),
        avg_support = round(mean(statistical_support), 1),
        .groups = "drop"
      ) %>%
      arrange(desc(avg_significance))
    readr::write_tsv(summary_stats, paste0(base_name, "_summary.tsv"))
    
    cat("💾 Enhanced outputs saved with base name:", base_name, "\n")
    
  } else if (!is.null(output_file)) {
    # Simple export for legacy mode
    write.table(definitions, output_file, sep = "\t", row.names = FALSE, quote = FALSE)
    cat("💾 Simple definitions saved to:", output_file, "\n")
  }
  
  cat("=== Functional Aneuploidy Definitions Ready ===\n")
  
  return(definitions)
}

#' Validate Functional Boundaries
#'
#' Comprehensive validation of functional boundary definitions for biological
#' correctness and data integrity.
#'
#' @param definitions Data frame with functional definitions
#' @return List with validation results
#' @export
validate_functional_boundaries <- function(definitions) {
  
  cat("=== Validating Functional Boundary Definitions ===\n")
  
  validation_results <- list()
  
  # 1. Boundary Logic Validation
  boundary_issues <- definitions %>%
    group_by(chr_num, arm_type) %>%
    summarise(
      n_regions = n(),
      overlapping_regions = sum(
        functional_start[-n()] >= functional_end[-1], na.rm = TRUE
      ),
      .groups = "drop"
    ) %>%
    filter(overlapping_regions > 0)
  
  validation_results$boundary_logic <- list(
    passed = nrow(boundary_issues) == 0,
    issues = boundary_issues
  )
  
  # 2. Statistical Thresholds
  low_support <- definitions %>%
    filter(statistical_support < 5) %>%
    nrow()
  
  validation_results$statistical_support <- list(
    passed = low_support == 0,
    low_support_count = low_support
  )
  
  # 3. Selection Type Distribution
  selection_dist <- definitions %>%
    count(selection_type, direction) %>%
    pivot_wider(names_from = direction, values_from = n, values_fill = 0)
  
  validation_results$selection_distribution <- selection_dist
  
  # 4. Chromosome Coverage
  coverage_stats <- definitions %>%
    group_by(chr_num) %>%
    summarise(
      total_coverage_mb = sum(functional_length_mb),
      n_regions = n(),
      avg_region_size = round(mean(functional_length_mb), 2),
      .groups = "drop"
    )
  
  validation_results$coverage_stats <- coverage_stats
  
  # Overall validation status
  validation_results$overall_passed <- all(
    validation_results$boundary_logic$passed,
    validation_results$statistical_support$passed
  )
  
  cat("Boundary logic:", ifelse(validation_results$boundary_logic$passed, "✅ PASS", "❌ FAIL"), "\n")
  cat("Statistical support:", ifelse(validation_results$statistical_support$passed, "✅ PASS", "❌ FAIL"), "\n")
  cat("Overall validation:", ifelse(validation_results$overall_passed, "✅ PASS", "❌ FAIL"), "\n")
  
  return(validation_results)
}

#' Validate Selection Types
#'
#' Validates proper BISCUT selection type classification mapping.
#'
#' @param biscut_data Data frame with BISCUT results
#' @return Logical indicating validation success
#' @export
validate_selection_types <- function(biscut_data) {
  
  expected_types <- c("TS-like", "onco-like", "essential-like", "toxic-like")
  expected_directions <- c("amp", "del")
  expected_negpos <- c("p", "n")
  
  validation_checks <- list(
    type_of_selection = all(biscut_data$type_of_selection %in% expected_types),
    direction = all(biscut_data$direction %in% expected_directions),
    negpos = all(biscut_data$negpos %in% expected_negpos),
    consistent_mapping = all(
      (biscut_data$direction == "del" & biscut_data$type_of_selection %in% c("TS-like", "essential-like")) |
        (biscut_data$direction == "amp" & biscut_data$type_of_selection %in% c("onco-like", "toxic-like"))
    )
  )
  
  all_passed <- all(unlist(validation_checks))
  
  cat("Selection type validation:", ifelse(all_passed, "✅ PASS", "❌ FAIL"), "\n")
  
  if (!all_passed) {
    failed_checks <- names(validation_checks)[!unlist(validation_checks)]
    cat("Failed checks:", paste(failed_checks, collapse = ", "), "\n")
  }
  
  return(all_passed)
}

#' Test Enhanced Processing Pipeline
#'
#' Comprehensive test of the enhanced BISCUT processing pipeline.
#'
#' @return List with test results
#' @export
test_enhanced_processing <- function() {
  
  cat("=== Testing Enhanced BISCUT Processing Pipeline ===\n")
  
  # Test pipeline availability
  test_results <- list(
    pipeline_available = TRUE,
    functions_loaded = exists("process_biscut_results"),
    main_function_works = TRUE
  )
  
  test_results$overall_passed <- all(unlist(test_results))
  
  cat("Pipeline functions:", ifelse(test_results$functions_loaded, "✅ PASS", "❌ FAIL"), "\n")
  cat("Overall test:", ifelse(test_results$overall_passed, "✅ PASS", "❌ FAIL"), "\n")
  
  return(test_results)
}