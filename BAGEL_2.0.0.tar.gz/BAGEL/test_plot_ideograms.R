## ---------------------------
##
## Script name: test_plot_ideograms.R
##
## Purpose of script: Test the modified plot_ideograms function with nested structure
##
## Author: Polly Hung
##
## Date Created: 2025-09-30
## Date Updated: 2025-09-30
##
## Copyright (c) Polly Hung, 2025
## Email: u3012149@connect.hku.hk
##
## ---------------------------

# Load required libraries
library(BAGEL)
library(dplyr)
library(ggplot2)
library(patchwork)

# Test with sample arm_definitions data
# This simulates chr19 data structure as provided by user
test_data <- data.frame(
  peak_id = c("19p_amp_cent_pos", "19p_amp_tel_neg", "19p_del_tel_neg",
              "19q_amp_cent_neg", "19q_amp_tel_neg", "19q_del_tel_neg", "19q_del_tel_pos"),
  chr = rep("chr19", 7),
  chr_arm = c("19p", "19p", "19p", "19q", "19q", "19q", "19q"),
  arm = c("p", "p", "p", "q", "q", "q", "q"),
  type = c("p_cent", "p_tel", "p_tel", "q_cent", "q_tel", "q_tel", "q_tel"),
  direction = c("amp", "amp", "del", "amp", "amp", "del", "del"),
  telcent = c("cent", "tel", "tel", "cent", "tel", "tel", "tel"),
  negpos = c("pos", "neg", "neg", "neg", "neg", "neg", "pos"),
  type_of_selection = c("onco-like", "toxic-like", "essential-like",
                        "toxic-like", "toxic-like", "essential-like", "TS-like"),
  functional_start = c(14130024, 284018, 284018, 28240494, 49284866, 36158917, 44167925),
  functional_end = c(24052992, 10666450, 14380151, 58808709, 58878226, 58878226, 58878226),
  p_start = rep(284018, 7),
  p_end = rep(24052992, 7),
  q_start = rep(28240494, 7),
  q_end = rep(58878226, 7),
  stringsAsFactors = FALSE
)

cat("Testing plot_ideograms with chr19 data (7 events)...\n")

# Run the function
result <- plot_ideograms(
  arm_definitions = test_data,
  output_dir = tempdir(),
  dir_name = "test_ideograms",
  plot_width = 3,
  plot_height = 3,
  save_plots = TRUE
)

# Verify structure
cat("\n=== Verification of Output Structure ===\n")
cat("1. Top-level names:", paste(names(result), collapse = ", "), "\n")
cat("2. Chromosomes plotted:", paste(names(result$plots_by_chromosome), collapse = ", "), "\n")
cat("3. Number of events in chr19:", length(result$plots_by_chromosome$chr19), "\n")
cat("4. Event IDs in chr19:", paste(names(result$plots_by_chromosome$chr19), collapse = ", "), "\n")
cat("5. Combined plot exists:", !is.null(result$combined_by_chromosome$chr19), "\n")
cat("6. Metadata - Total events:", result$plot_metadata$total_events, "\n")
cat("7. Metadata - Events per chromosome:", result$plot_metadata$events_per_chromosome, "\n")

cat("\n=== Test Access Patterns ===\n")
cat("Access specific event plot: result$plots_by_chromosome$chr19$`19p_amp_cent_pos`\n")
cat("Access chr19 combined grid: result$combined_by_chromosome$chr19\n")
cat("Plot class:", class(result$plots_by_chromosome$chr19$`19p_amp_cent_pos`)[1], "\n")

cat("\n✅ Test completed successfully!\n")
cat("Plots saved to:", result$output_directory, "\n")